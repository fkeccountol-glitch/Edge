plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.example.edge"; compileSdk = 35
    defaultConfig { applicationId = "com.example.edge"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}
