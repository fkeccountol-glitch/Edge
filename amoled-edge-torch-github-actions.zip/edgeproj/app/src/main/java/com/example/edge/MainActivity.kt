package com.example.edge

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.*
import android.widget.*

class MainActivity : Activity() {
    private var overlay: View? = null
    private var wm: WindowManager? = null
    private var width = 18
    private var brightness = 220
    override fun onCreate(b: Bundle?) { super.onCreate(b); buildUi() }
    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,40,32,32); setBackgroundColor(Color.BLACK) }
        fun label(t:String)=TextView(this).apply { text=t; setTextColor(Color.WHITE); textSize=18f; setPadding(0,18,0,8) }
        root.addView(label("AMOLED Edge Torch")); root.addView(label("Edge width"))
        val ws=SeekBar(this).apply { max=80; progress=width; setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(s:SeekBar?,p:Int,f:Boolean){width=p.coerceAtLeast(2)};override fun onStartTrackingTouch(s:SeekBar?){};override fun onStopTrackingTouch(s:SeekBar?){} })}; root.addView(ws)
        root.addView(label("Brightness")); val bs=SeekBar(this).apply { max=255; progress=brightness; setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(s:SeekBar?,p:Int,f:Boolean){brightness=p};override fun onStartTrackingTouch(s:SeekBar?){};override fun onStopTrackingTouch(s:SeekBar?){} })}; root.addView(bs)
        val start=Button(this).apply { text="Start edge lighting"; setOnClickListener { if(!Settings.canDrawOverlays(this@MainActivity)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) else startOverlay() } }; root.addView(start)
        root.addView(Button(this).apply { text="Stop"; setOnClickListener { stopOverlay() } }); setContentView(root)
    }
    private fun startOverlay(){ if(overlay!=null)return; wm=getSystemService(WINDOW_SERVICE) as WindowManager
        overlay=object:View(this){override fun onDraw(c:android.graphics.Canvas){super.onDraw(c);val p=android.graphics.Paint();p.color=Color.argb(255,0,brightness,brightness);c.drawRect(0f,0f,width.toFloat(),this@MainActivity.width.toFloat(),p);c.drawRect((c.width-this@MainActivity.width).toFloat(),0f,c.width.toFloat(),c.height.toFloat(),p);c.drawRect(0f,0f,c.width.toFloat(),this@MainActivity.width.toFloat(),p);c.drawRect(0f,(c.height-this@MainActivity.width).toFloat(),c.width.toFloat(),c.height.toFloat(),p)}}
        val type=if(android.os.Build.VERSION.SDK_INT>=26)WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        wm!!.addView(overlay,WindowManager.LayoutParams(-1,-1,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,PixelFormat.TRANSLUCENT)) }
    private fun stopOverlay(){overlay?.let{wm?.removeView(it)};overlay=null}
    override fun onDestroy(){stopOverlay();super.onDestroy()}
}
